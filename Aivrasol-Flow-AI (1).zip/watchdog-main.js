(function () {
  "use strict";

  const HEARTBEAT_TYPE = "FLOW_BY_PAK_EXTENSION_HEARTBEAT";
  const DISCONNECTED_TYPE = "FLOW_BY_PAK_EXTENSION_DISCONNECTED";
  const SIGN_OUT_URL = "https://labs.google/fx/api/auth/signout";
  const FLOW_URL = "https://labs.google/fx/tools/flow";
  const HEARTBEAT_TIMEOUT_MS = 2500;

  let lastHeartbeat = 0;
  let armed = false;
  let logoutStarted = false;

  window.addEventListener("message", (event) => {
    if (event.source !== window || !event.data) return;

    if (event.data.type === DISCONNECTED_TYPE) {
      if (armed) forceFlowLogout();
      return;
    }

    if (event.data.type !== HEARTBEAT_TYPE) return;

    armed = true;
    lastHeartbeat = Date.now();
  });

  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible" && armed) {
      // Give the isolated extension context time to resume after a sleeping tab.
      lastHeartbeat = Date.now();
    }
  });

  function clearPageSession() {
    try {
      sessionStorage.clear();
    } catch (_error) {}

    try {
      localStorage.setItem("__flow_by_pak_extension_disconnected__", "1");
    } catch (_error) {}

    try {
      for (const cookie of document.cookie.split(";")) {
        const separator = cookie.indexOf("=");
        const name = (separator >= 0 ? cookie.slice(0, separator) : cookie).trim();
        if (!name) continue;

        for (const domain of ["labs.google", ".labs.google", "google.com", ".google.com"]) {
          document.cookie =
            `${name}=; Max-Age=0; path=/; domain=${domain}; SameSite=Lax; Secure`;
        }
        document.cookie = `${name}=; Max-Age=0; path=/; SameSite=Lax; Secure`;
      }
    } catch (_error) {}
  }

  function readCsrfToken() {
    try {
      const csrfCookieNames = [
        "__Host-next-auth.csrf-token",
        "__Secure-next-auth.csrf-token",
        "next-auth.csrf-token"
      ];
      for (const part of document.cookie.split(";")) {
        const separator = part.indexOf("=");
        if (separator < 0) continue;
        const name = part.slice(0, separator).trim();
        if (!csrfCookieNames.includes(name)) continue;
        const value = decodeURIComponent(part.slice(separator + 1));
        return value.split("|")[0] || value;
      }
    } catch (_error) {}
    return "";
  }

  async function submitGoogleSignOut(csrfToken) {
    await fetch(SIGN_OUT_URL, {
      method: "POST",
      credentials: "include",
      cache: "no-store",
      redirect: "follow",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      body: new URLSearchParams({
        csrfToken,
        callbackUrl: FLOW_URL
      }).toString()
    });
  }

  async function fetchCsrfToken() {
    const cookieToken = readCsrfToken();
    if (cookieToken) return cookieToken;

    try {
      const controller = new AbortController();
      const timeoutId = window.setTimeout(() => controller.abort(), 1200);
      const response = await fetch("https://labs.google/fx/api/auth/csrf", {
        method: "GET",
        credentials: "include",
        cache: "no-store",
        signal: controller.signal
      });
      window.clearTimeout(timeoutId);
      if (response.ok) {
        const data = await response.json();
        if (data && data.csrfToken) return data.csrfToken;
      }
    } catch (_error) {}

    try {
      const controller = new AbortController();
      const timeoutId = window.setTimeout(() => controller.abort(), 1200);
      const response = await fetch(SIGN_OUT_URL, {
        method: "GET",
        credentials: "include",
        cache: "no-store",
        signal: controller.signal
      });
      window.clearTimeout(timeoutId);
      const html = await response.text();
      const match =
        html.match(/name=["']csrfToken["'][^>]*value=["']([^"']+)["']/i) ||
        html.match(/value=["']([^"']+)["'][^>]*name=["']csrfToken["']/i);
      if (match && match[1]) return match[1];
    } catch (_error) {}

    return "";
  }

  async function forceFlowLogout() {
    if (logoutStarted) return;
    logoutStarted = true;
    let csrfToken = readCsrfToken();
    if (!csrfToken) {
      csrfToken = await Promise.race([
        fetchCsrfToken(),
        new Promise((resolve) => window.setTimeout(() => resolve(""), 2600))
      ]);
    }
    clearPageSession();

    if (csrfToken && document.documentElement) {
      try {
        await Promise.race([
          submitGoogleSignOut(csrfToken),
          new Promise((resolve) => window.setTimeout(resolve, 2000))
        ]);
      } catch (_error) {}
      location.replace(FLOW_URL);
      return;
    }

    // Never expose Google's confirmation screen. If the auth endpoint cannot
    // provide a token, return to Flow and let the short cookie lease expire.
    location.replace(FLOW_URL);
  }

  window.setInterval(() => {
    if (
      armed &&
      document.visibilityState === "visible" &&
      Date.now() - lastHeartbeat > HEARTBEAT_TIMEOUT_MS
    ) {
      forceFlowLogout();
    }
  }, 100);
})();
