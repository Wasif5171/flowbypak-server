(function () {
  "use strict";

  const FLOW_AI_URL = "https://labs.google/fx/tools/flow";
  const DEFAULT_PORTAL_URL = "https://flowbypak.site";

  const updateBanner = document.getElementById("updateBanner");
  const newVerText = document.getElementById("newVerText");
  const statusDot = document.getElementById("statusDot");
  const statusTitle = document.getElementById("statusTitle");
  const statusMessage = document.getElementById("statusMessage");
  const infoCard = document.getElementById("infoCard");
  const userEmail = document.getElementById("userEmail");
  const subDays = document.getElementById("subDays");
  const trialBadge = document.getElementById("trialBadge");
  const launchFlowBtn = document.getElementById("launchFlowBtn");
  const openPortalBtn = document.getElementById("openPortalBtn");
  const syncNowBtn = document.getElementById("syncNowBtn");
  const lastSyncText = document.getElementById("lastSyncText");
  const siteName = document.getElementById("siteName");
  const headerLogo = document.getElementById("headerLogo");

  async function loadState() {
    const state = await chrome.storage.local.get([
      "status",
      "statusMessage",
      "userEmail",
      "daysRemaining",
      "timeDisplay",
      "userType",
      "lastSyncTime",
      "portalUrl",
      "activeSlot",
      "availableSlots",
      "updateAvailable",
      "serverVersion",
      "brand_primaryColor",
      "brand_accentColor"
    ]);

    applyBranding(state);
    renderUI(state);
  }

  function applyBranding(state) {
    // Apply branding colors
    if (state.brand_primaryColor) {
      document.documentElement.style.setProperty('--primary', state.brand_primaryColor);
      document.documentElement.style.setProperty('--primary-light', state.brand_primaryColor);
    }
    if (state.brand_accentColor) {
      document.documentElement.style.setProperty('--accent', state.brand_accentColor);
      document.documentElement.style.setProperty('--accent-hover', state.brand_accentColor);
    }

    // Keep the extension name and logo fixed to Flow by Pak.
    if (siteName) siteName.textContent = "Flow by Pak";
    const subTitle = document.getElementById("siteSubTitle");
    if (subTitle) subTitle.textContent = "AI Video Platform";
    const popTitle = document.getElementById("popupTitle");
    if (popTitle) popTitle.textContent = "Flow by Pak";
    if (headerLogo) headerLogo.src = "logo.png";
  }

  function renderUI(state) {
    const status = state.status || "disconnected";
    let portalUrl = state.portalUrl || DEFAULT_PORTAL_URL;

    if (openPortalBtn) {
      openPortalBtn.href = portalUrl;
    }

    if (state.updateAvailable && updateBanner) {
      updateBanner.hidden = false;
      if (newVerText) newVerText.textContent = `v${state.serverVersion || "1.0"}`;
    } else if (updateBanner) {
      updateBanner.hidden = true;
    }

    if (status === "connected") {
      if (statusDot) statusDot.className = "dot connected";
      if (statusTitle) statusTitle.textContent = "Connected";
      if (statusMessage) statusMessage.textContent = "Portal Connected & Active";
      if (launchFlowBtn) launchFlowBtn.disabled = false;
      if (infoCard) infoCard.hidden = false;
      if (userEmail) userEmail.textContent = state.userEmail || "Member";
      const slotSelect = document.getElementById("slotSelect");
      if (slotSelect) {
        const rawSlots = state.availableSlots || [];
        const active = state.activeSlot || "C1";
        slotSelect.innerHTML = "";

        // available_slots from server are objects: {key: "C1", name: "...", health: "live"}
        // Or could be plain strings like "C1"
        const slots = rawSlots.map(s => {
          if (typeof s === "string") return { key: s };
          return s;
        });

        if (slots.length === 0) {
          const opt = document.createElement("option");
          opt.value = "C1";
          opt.textContent = "Account 1";
          slotSelect.appendChild(opt);
        } else {
          slots.forEach(s => {
            const key = s.key || "C1";
            const num = key.replace("C", "");
            const opt = document.createElement("option");
            opt.value = key;
            opt.textContent = `Account ${num}`;
            if (key === active) opt.selected = true;
            slotSelect.appendChild(opt);
          });
        }

        slotSelect.onchange = function() {
          const selected = this.value;
          chrome.runtime.sendMessage({ action: "SWITCH_COOKIE_SLOT", slot: selected }, () => {
            setTimeout(loadState, 500);
          });
        };
      }

      // Show time display or days
      const displayText = state.timeDisplay || `${state.daysRemaining ?? 0} days left`;
      if (subDays) subDays.textContent = displayText;

      // Show trial badge
      if (trialBadge) {
        trialBadge.hidden = (state.userType !== 'trial');
      }
    } else if (status === "pending") {
      if (statusDot) statusDot.className = "dot pending";
      if (statusTitle) statusTitle.textContent = "Pending Approval";
      if (statusMessage) statusMessage.textContent = "Waiting for admin to approve your account";
      if (launchFlowBtn) launchFlowBtn.disabled = true;
      if (infoCard) infoCard.hidden = true;
      if (trialBadge) trialBadge.hidden = true;
    } else if (status === "expired") {
      if (statusDot) statusDot.className = "dot expired";
      if (statusTitle) statusTitle.textContent = "Subscription Expired";
      if (statusMessage) statusMessage.textContent = "Please renew at portal";
      if (launchFlowBtn) launchFlowBtn.disabled = true;
      if (infoCard) infoCard.hidden = true;
      if (trialBadge) trialBadge.hidden = true;
    } else {
      if (statusDot) statusDot.className = "dot disconnected";
      if (statusTitle) statusTitle.textContent = "Not Connected";
      if (statusMessage) statusMessage.textContent = "Please log in to portal";
      if (launchFlowBtn) launchFlowBtn.disabled = true;
      if (infoCard) infoCard.hidden = true;
      if (trialBadge) trialBadge.hidden = true;
    }

    if (state.lastSyncTime && lastSyncText) {
      const timeStr = new Date(state.lastSyncTime).toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit"
      });
      lastSyncText.textContent = `Last connected: ${timeStr}`;
    } else if (lastSyncText) {
      lastSyncText.textContent = "Last connected: Never";
    }
  }

  if (openPortalBtn) {
    openPortalBtn.onclick = (e) => {
      e.preventDefault();
      const targetUrl = openPortalBtn.href || DEFAULT_PORTAL_URL;
      chrome.tabs.create({ url: targetUrl });
    };
  }

  if (launchFlowBtn) {
    launchFlowBtn.onclick = () => {
      chrome.tabs.create({ url: FLOW_AI_URL });
    };
  }

  if (syncNowBtn) {
    syncNowBtn.addEventListener("click", () => {
      syncNowBtn.disabled = true;
      syncNowBtn.textContent = "🔄 Connecting...";
      chrome.runtime.sendMessage({ action: "TRIGGER_SYNC" }, (response) => {
        syncNowBtn.disabled = false;
        syncNowBtn.textContent = "🔄 Connect Now";
        loadState();
      });
    });
  }

  chrome.storage.onChanged.addListener(() => {
    loadState();
  });

  loadState();

  chrome.runtime.sendMessage({ action: "TRIGGER_SYNC" }, () => {
    loadState();
  });
})();
