(function (root) {
  "use strict";

  const DAY_SECONDS = 24 * 60 * 60;
  const MAX_EXTENSION_DAYS = 400;
  const SAME_SITE_VALUES = new Set([
    "no_restriction",
    "lax",
    "strict",
    "unspecified"
  ]);

  function parseCookieInput(text) {
    if (typeof text !== "string" || !text.trim()) {
      throw new Error("Paste a JSON cookie array first.");
    }

    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch (error) {
      throw new Error(`The pasted text is not valid JSON: ${error.message}`);
    }

    const cookies = Array.isArray(parsed) ? parsed : parsed && parsed.cookies;
    if (!Array.isArray(cookies)) {
      throw new Error("Expected a JSON array, or an object with a cookies array.");
    }
    if (cookies.length === 0) {
      throw new Error("The cookie list is empty.");
    }
    if (cookies.length > 500) {
      throw new Error("For safety, import no more than 500 cookies at once.");
    }

    return cookies;
  }

  function normalizeDomain(value) {
    if (typeof value !== "string" || !value.trim()) {
      throw new Error("Cookie domain is missing.");
    }

    const original = value.trim().toLowerCase();
    const clean = original.replace(/^\.+/, "");
    if (!clean || clean.includes(":") || clean.includes("/") || /\s/.test(clean)) {
      throw new Error(`Invalid cookie domain: ${value}`);
    }
    return { original, clean };
  }

  function isAllowedDomain(domain) {
    return domain === "labs.google" ||
      domain.endsWith(".labs.google") ||
      domain === "google.com" ||
      domain.endsWith(".google.com");
  }

  function normalizeSameSite(value) {
    if (value === null || value === undefined || value === "") {
      return undefined;
    }

    const normalized = String(value).toLowerCase().replaceAll("-", "_");
    const mapped = normalized === "none" ? "no_restriction" : normalized;
    if (!SAME_SITE_VALUES.has(mapped)) {
      throw new Error(`Unsupported SameSite value: ${value}`);
    }
    return mapped;
  }

  function normalizePath(value) {
    if (value === null || value === undefined || value === "") {
      return "/";
    }
    if (typeof value !== "string" || !value.startsWith("/")) {
      throw new Error("Cookie path must start with /.");
    }
    return value;
  }

  function normalizePartitionKey(value) {
    if (value === null || value === undefined) {
      return undefined;
    }
    if (typeof value !== "object" || Array.isArray(value)) {
      throw new Error("partitionKey must be an object.");
    }

    const output = {};
    if (value.topLevelSite !== undefined) {
      try {
        const site = new URL(value.topLevelSite);
        if (site.protocol !== "https:" && site.protocol !== "http:") {
          throw new Error();
        }
        output.topLevelSite = site.origin;
      } catch (_error) {
        throw new Error("partitionKey.topLevelSite must be an HTTP(S) origin.");
      }
    }
    if (value.hasCrossSiteAncestor !== undefined) {
      output.hasCrossSiteAncestor = Boolean(value.hasCrossSiteAncestor);
    }
    return Object.keys(output).length ? output : undefined;
  }

  function resolveExpiration(cookie, minimumDays, nowSeconds) {
    const original = Number(cookie.expirationDate);
    const hasOriginal = Number.isFinite(original) && original > 0;
    const days = Number(minimumDays);

    if (!Number.isFinite(days) || days <= 0) {
      if (hasOriginal) {
        if (original <= nowSeconds) {
          throw new Error("Cookie has already expired. Select a minimum lifetime to import it locally.");
        }
        return original;
      }
      return undefined;
    }

    const boundedDays = Math.min(days, MAX_EXTENSION_DAYS);
    const minimum = nowSeconds + boundedDays * DAY_SECONDS;
    return hasOriginal ? Math.max(original, minimum) : minimum;
  }

  function buildSetDetails(cookie, options = {}) {
    if (!cookie || typeof cookie !== "object" || Array.isArray(cookie)) {
      throw new Error("Each cookie must be a JSON object.");
    }
    if (typeof cookie.name !== "string") {
      throw new Error("Cookie name must be a string.");
    }
    if (typeof cookie.value !== "string") {
      throw new Error(`Cookie ${cookie.name || "(unnamed)"} has a non-string value.`);
    }

    const domain = normalizeDomain(cookie.domain);
    if (!isAllowedDomain(domain.clean)) {
      throw new Error(`Domain ${domain.clean} is outside this extension's allowed Google hosts.`);
    }

    const isHostPrefix = cookie.name.startsWith("__Host-");
    const isSecurePrefix = cookie.name.startsWith("__Secure-");
    const inferredHostOnly = !domain.original.startsWith(".");
    const hostOnly = isHostPrefix ||
      (typeof cookie.hostOnly === "boolean" ? cookie.hostOnly : inferredHostOnly);
    const path = isHostPrefix ? "/" : normalizePath(cookie.path);
    const sameSite = normalizeSameSite(cookie.sameSite);
    const secure = Boolean(cookie.secure) || isHostPrefix || isSecurePrefix ||
      sameSite === "no_restriction";
    const nowSeconds = Number.isFinite(options.nowSeconds)
      ? options.nowSeconds
      : Date.now() / 1000;

    const details = {
      url: `${secure ? "https" : "http"}://${domain.clean}${path}`,
      name: cookie.name,
      value: cookie.value,
      path,
      secure,
      httpOnly: Boolean(cookie.httpOnly)
    };

    // Omitting domain is what creates a true host-only cookie. This is also
    // mandatory for the __Host- prefix.
    if (!hostOnly) {
      details.domain = domain.original.startsWith(".")
        ? domain.original
        : `.${domain.clean}`;
    }

    if (sameSite !== undefined) {
      details.sameSite = sameSite;
    }

    const expirationDate = resolveExpiration(
      cookie,
      options.minimumDays,
      nowSeconds
    );
    if (expirationDate !== undefined) {
      details.expirationDate = expirationDate;
    }

    const partitionKey = normalizePartitionKey(cookie.partitionKey);
    if (partitionKey !== undefined) {
      details.partitionKey = partitionKey;
    }

    return {
      details,
      expected: {
        domain: domain.clean,
        hostOnly,
        path,
        secure,
        httpOnly: Boolean(cookie.httpOnly),
        expirationDate
      }
    };
  }

  function verifyCookie(actual, expected) {
    const problems = [];
    if (!actual) return ["Chrome returned no cookie after writing it."];
    if (actual.domain.replace(/^\./, "") !== expected.domain) {
      problems.push("domain does not match");
    }
    if (actual.hostOnly !== expected.hostOnly) {
      problems.push("host-only scope does not match");
    }
    if (actual.path !== expected.path) problems.push("path does not match");
    if (actual.secure !== expected.secure) problems.push("Secure flag does not match");
    if (actual.httpOnly !== expected.httpOnly) problems.push("HttpOnly flag does not match");
    if (expected.expirationDate !== undefined) {
      if (!Number.isFinite(actual.expirationDate) ||
          Math.abs(actual.expirationDate - expected.expirationDate) > 2) {
        problems.push("expiration does not match");
      }
    } else if (!actual.session) {
      problems.push("expected a session cookie");
    }
    return problems;
  }

  async function clearCookiesForDomains(domains = ["labs.google", "google.com"]) {
    if (!chrome || !chrome.cookies) return 0;
    let clearedCount = 0;
    for (const domain of domains) {
      try {
        const cookies = await chrome.cookies.getAll({ domain });
        for (const cookie of cookies) {
          const protocol = cookie.secure ? "https:" : "http:";
          const cookieUrl = `${protocol}//${cookie.domain.replace(/^\./, "")}${cookie.path}`;
          await chrome.cookies.remove({
            url: cookieUrl,
            name: cookie.name,
            ...(cookie.partitionKey ? { partitionKey: cookie.partitionKey } : {})
          });
          clearedCount += 1;
        }
      } catch (err) {
        console.warn(`Failed to clear cookies for domain ${domain}:`, err);
      }
    }
    return clearedCount;
  }

  root.CookieCore = Object.freeze({
    parseCookieInput,
    buildSetDetails,
    verifyCookie,
    clearCookiesForDomains
  });
})(globalThis);

