(function () {
  "use strict";

  const SHIELD_ID = "flow-sparx-profile-shield";
  const HEADER_MAX_Y = 180;
  const RESCAN_INTERVAL_MS = 750;
  const observedRoots = new WeakSet();
  const observers = [];
  const blockedEvents = [
    "pointerdown",
    "pointerup",
    "mousedown",
    "mouseup",
    "click",
    "dblclick",
    "auxclick",
    "contextmenu",
    "touchstart",
    "touchend"
  ];

  let profileButton = null;
  let shield = null;
  let scheduled = false;
  let stopped = false;
  const originalButtonState = new WeakMap();

  function normalizeText(value) {
    return String(value || "")
      .replace(/\s+/g, " ")
      .trim()
      .toUpperCase();
  }

  function isVisible(element) {
    if (!(element instanceof Element)) return false;

    const rectangle = element.getBoundingClientRect();
    if (rectangle.width <= 0 || rectangle.height <= 0) return false;

    const style = getComputedStyle(element);
    return style.display !== "none" &&
      style.visibility !== "hidden" &&
      Number(style.opacity || 1) > 0;
  }

  function containsUltra(element) {
    if (!(element instanceof Element)) return false;

    const rendered = normalizeText(element.innerText || element.textContent);
    const accessible = normalizeText([
      element.getAttribute("aria-label"),
      element.getAttribute("title")
    ].filter(Boolean).join(" "));

    return rendered.includes("ULTRA") || accessible.includes("ULTRA");
  }

  function collectRoots() {
    const roots = [document];

    for (let index = 0; index < roots.length; index += 1) {
      for (const element of roots[index].querySelectorAll("*")) {
        if (element.shadowRoot) roots.push(element.shadowRoot);
      }
    }

    return roots;
  }

  function findClickableAncestor(label) {
    const selector = [
      "button",
      "a",
      "[role='button']",
      "[tabindex]",
      "[aria-haspopup]",
      "[aria-expanded]"
    ].join(",");

    const clickable = label.closest(selector);
    if (clickable && isVisible(clickable)) {
      const rectangle = clickable.getBoundingClientRect();
      if (rectangle.width <= 220 && rectangle.height <= 100) return clickable;
    }

    let fallback = label;
    let current = label.parentElement;

    for (let depth = 0; current && depth < 5; depth += 1) {
      const rectangle = current.getBoundingClientRect();
      if (rectangle.width > 220 || rectangle.height > 100 || !containsUltra(current)) break;

      fallback = current;
      const style = getComputedStyle(current);
      if (
        style.cursor === "pointer" ||
        current.hasAttribute("onclick") ||
        current.hasAttribute("aria-haspopup")
      ) {
        return current;
      }
      current = current.parentElement;
    }

    const rectangle = fallback.getBoundingClientRect();
    const style = getComputedStyle(fallback);
    const isActuallyClickable =
      style.cursor === "pointer" ||
      fallback.hasAttribute("onclick") ||
      fallback.hasAttribute("aria-haspopup") ||
      fallback.getAttribute("role") === "button" ||
      fallback instanceof HTMLButtonElement ||
      fallback instanceof HTMLAnchorElement;

    return isActuallyClickable &&
      rectangle.width <= 220 &&
      rectangle.height <= 100
      ? fallback
      : null;
  }

  function findProfileButton() {
    const candidates = [];

    for (const root of collectRoots()) {
      observeRoot(root);

      const elements = root.querySelectorAll(
        "button, [role='button'], [aria-label], [title], span, div"
      );

      for (const element of elements) {
        if (element.id === SHIELD_ID || !isVisible(element)) continue;

        const rectangle = element.getBoundingClientRect();
        if (rectangle.top < 0 || rectangle.top > HEADER_MAX_Y) continue;
        if (rectangle.left < window.innerWidth * 0.45) continue;
        // Never consider a page/card container. Locking a large container with
        // `inert` also disables every control below it and looks like a frozen UI.
        if (rectangle.width > 220 || rectangle.height > 100) continue;

        const rendered = normalizeText(element.innerText || element.textContent);
        const accessible = normalizeText([
          element.getAttribute("aria-label"),
          element.getAttribute("title")
        ].filter(Boolean).join(" "));

        const exact = rendered === "ULTRA";
        if (!rendered.includes("ULTRA") && !accessible.includes("ULTRA")) continue;

        const area = rectangle.width * rectangle.height;
        const score = (exact ? 0 : 100000) + rendered.length * 100 + area;
        const clickable = findClickableAncestor(element);
        if (clickable) candidates.push({ element: clickable, score });
      }
    }

    candidates.sort((left, right) => left.score - right.score);
    if (!candidates.length) return null;

    return candidates[0].element;
  }

  function createShield() {
    const element = document.createElement("div");
    element.id = SHIELD_ID;
    element.tabIndex = -1;
    element.title = "Account menu locked";
    element.setAttribute("aria-hidden", "true");

    const lockBadge = document.createElement("span");
    lockBadge.setAttribute("aria-hidden", "true");
    Object.assign(lockBadge.style, {
      position: "absolute",
      left: "-24px",
      top: "50%",
      transform: "translateY(-50%)",
      display: "flex",
      width: "20px",
      height: "20px",
      alignItems: "center",
      justifyContent: "center",
      border: "1px solid rgba(174, 151, 255, 0.7)",
      borderRadius: "7px",
      background: "linear-gradient(145deg, #5a3cc7, #2b1a70)",
      boxShadow: "0 0 10px rgba(132, 91, 255, 0.55)",
      color: "#ffffff",
      pointerEvents: "none"
    });

    const svgNamespace = "http://www.w3.org/2000/svg";
    const lockSvg = document.createElementNS(svgNamespace, "svg");
    lockSvg.setAttribute("viewBox", "0 0 24 24");
    lockSvg.setAttribute("width", "13");
    lockSvg.setAttribute("height", "13");
    lockSvg.setAttribute("aria-hidden", "true");

    const lockPath = document.createElementNS(svgNamespace, "path");
    lockPath.setAttribute("fill", "currentColor");
    lockPath.setAttribute(
      "d",
      "M17 8h-1V6a4 4 0 0 0-8 0v2H7a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-9a2 2 0 0 0-2-2Zm-7-2a2 2 0 1 1 4 0v2h-4V6Zm3 10.73V18h-2v-1.27a2 2 0 1 1 2 0Z"
    );

    lockSvg.appendChild(lockPath);
    lockBadge.appendChild(lockSvg);
    element.appendChild(lockBadge);

    Object.assign(element.style, {
      position: "fixed",
      display: "none",
      zIndex: "2147483647",
      margin: "0",
      padding: "0",
      border: "0",
      background: "rgba(0, 0, 0, 0.001)",
      pointerEvents: "auto",
      touchAction: "none",
      userSelect: "none",
      cursor: "not-allowed",
      boxSizing: "border-box",
      overflow: "visible"
    });

    document.body.appendChild(element);
    return element;
  }

  function eventTouchesLockedArea(event) {
    const path = typeof event.composedPath === "function"
      ? event.composedPath()
      : [];

    const touchesShield = Boolean(shield) &&
      (event.target === shield || path.includes(shield));

    const targetIsNode = event.target instanceof Node;
    const touchesProfile = Boolean(profileButton) && targetIsNode &&
      (event.target === profileButton || profileButton.contains(event.target) || path.includes(profileButton));

    return touchesShield || touchesProfile;
  }

  function blockEvent(event) {
    if (!eventTouchesLockedArea(event)) return;

    if (event.cancelable) event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
  }

  function blockKeyboard(event) {
    if (!profileButton) return;

    const root = profileButton.getRootNode();
    const activeElement = root && "activeElement" in root
      ? root.activeElement
      : document.activeElement;

    const eventTargetIsNode = event.target instanceof Node;
    const activeIsNode = activeElement instanceof Node;
    const targetsProfile =
      (eventTargetIsNode && (event.target === profileButton || profileButton.contains(event.target))) ||
      (activeIsNode && (activeElement === profileButton || profileButton.contains(activeElement)));

    if (!targetsProfile) return;
    if (!["Enter", " ", "Spacebar", "ArrowDown"].includes(event.key)) return;

    if (event.cancelable) event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    if (typeof profileButton.blur === "function") profileButton.blur();
  }

  function blockFocus(event) {
    if (!profileButton || !(event.target instanceof Node)) return;
    if (event.target !== profileButton && !profileButton.contains(event.target)) return;

    if (typeof event.target.blur === "function") event.target.blur();
    event.stopPropagation();
    event.stopImmediatePropagation();
  }

  function disableProfileButton(button) {
    if (profileButton && profileButton !== button) restoreProfileButton(profileButton);

    profileButton = button;
    if (!originalButtonState.has(button)) {
      originalButtonState.set(button, {
        ariaDisabled: button.getAttribute("aria-disabled"),
        locked: button.getAttribute("data-flow-sparx-locked"),
        tabIndex: button.getAttribute("tabindex"),
        inert: "inert" in button ? button.inert : undefined,
        cursor: button.style.cursor
      });
    }
    button.setAttribute("aria-disabled", "true");
    button.setAttribute("data-flow-sparx-locked", "true");
    button.tabIndex = -1;
    if ("inert" in button) button.inert = true;
    button.style.cursor = "not-allowed";
  }

  function restoreAttribute(element, name, value) {
    if (value === null) element.removeAttribute(name);
    else element.setAttribute(name, value);
  }

  function restoreProfileButton(button) {
    if (!(button instanceof HTMLElement)) return;
    const state = originalButtonState.get(button);
    if (!state) return;

    restoreAttribute(button, "aria-disabled", state.ariaDisabled);
    restoreAttribute(button, "data-flow-sparx-locked", state.locked);
    restoreAttribute(button, "tabindex", state.tabIndex);
    if ("inert" in button && state.inert !== undefined) button.inert = state.inert;
    button.style.cursor = state.cursor;
    originalButtonState.delete(button);
  }

  function positionShield() {
    if (!shield || !profileButton || !isVisible(profileButton)) {
      if (shield) shield.style.display = "none";
      return;
    }

    const rectangle = profileButton.getBoundingClientRect();
    const padding = 3;
    shield.style.left = `${Math.round(rectangle.left - padding)}px`;
    shield.style.top = `${Math.round(rectangle.top - padding)}px`;
    shield.style.width = `${Math.round(rectangle.width + padding * 2)}px`;
    shield.style.height = `${Math.round(rectangle.height + padding * 2)}px`;
    shield.style.borderRadius = getComputedStyle(profileButton).borderRadius || "12px";
    shield.style.display = "block";
  }

  function observeRoot(root) {
    if (observedRoots.has(root)) return;
    observedRoots.add(root);

    const observer = new MutationObserver((mutations) => {
      const meaningful = mutations.some((mutation) => {
        const target = mutation.target;
        return !shield || (target !== shield && !shield.contains(target));
      });
      if (meaningful) scheduleSync();
    });

    observer.observe(root, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
      attributeFilter: ["class", "aria-label", "aria-expanded", "aria-haspopup"]
    });
    observers.push(observer);
  }

  function syncShield() {
    scheduled = false;
    if (stopped || !document.body) return;

    for (const root of collectRoots()) observeRoot(root);

    if (!shield || !shield.isConnected) shield = createShield();

    const currentRectangle = profileButton
      ? profileButton.getBoundingClientRect()
      : null;
    const currentButtonIsValid = profileButton &&
      profileButton.isConnected &&
      isVisible(profileButton) &&
      containsUltra(profileButton) &&
      currentRectangle.top >= 0 &&
      currentRectangle.top <= HEADER_MAX_Y &&
      currentRectangle.left >= window.innerWidth * 0.45 &&
      currentRectangle.width <= 220 &&
      currentRectangle.height <= 100;

    if (!currentButtonIsValid) {
      if (profileButton) restoreProfileButton(profileButton);
      profileButton = null;
      profileButton = findProfileButton();
      if (profileButton) disableProfileButton(profileButton);
    }

    positionShield();
  }

  function scheduleSync() {
    if (scheduled || stopped) return;
    scheduled = true;
    requestAnimationFrame(syncShield);
  }

  for (const eventName of blockedEvents) {
    document.addEventListener(eventName, blockEvent, {
      capture: true,
      passive: false
    });
  }

  document.addEventListener("keydown", blockKeyboard, {
    capture: true,
    passive: false
  });
  document.addEventListener("focusin", blockFocus, {
    capture: true,
    passive: false
  });

  function start() {
    if (!document.documentElement) {
      window.setTimeout(start, 25);
      return;
    }
    observeRoot(document);
    scheduleSync();
  }

  window.addEventListener("resize", scheduleSync, { passive: true });
  window.addEventListener("scroll", scheduleSync, { passive: true, capture: true });

  const intervalId = window.setInterval(scheduleSync, RESCAN_INTERVAL_MS);
  window.addEventListener("pagehide", () => {
    stopped = true;
    window.clearInterval(intervalId);
    if (profileButton) restoreProfileButton(profileButton);
    for (const observer of observers) observer.disconnect();
  }, { once: true });

  start();
})();

// Hide the Flow home-page history and expose only a New project action.
(function () {
  "use strict";

  const PRIVACY_SCREEN_ID = "flow-by-pak-new-project-only";
  const FLOW_HOME_PATH = "/fx/tools/flow";
  let lastKnownUrl = "";

  function normalizePath(pathname) {
    return String(pathname || "").replace(/\/+$/, "") || "/";
  }

  function isFlowHomePage() {
    return location.hostname === "labs.google" &&
      normalizePath(location.pathname) === FLOW_HOME_PATH;
  }

  function normalizedText(element) {
    return String(element && (element.innerText || element.textContent) || "")
      .replace(/\s+/g, " ")
      .trim()
      .toUpperCase();
  }

  function isVisible(element) {
    if (!(element instanceof HTMLElement)) return false;
    const rectangle = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    return rectangle.width > 0 &&
      rectangle.height > 0 &&
      style.display !== "none" &&
      style.visibility !== "hidden";
  }

  function findNativeNewProjectButton() {
    const candidates = [];
    const elements = document.querySelectorAll(
      "button, a, [role='button'], [tabindex], div, span"
    );

    for (const element of elements) {
      if (element.closest(`#${PRIVACY_SCREEN_ID}`) || !isVisible(element)) continue;
      const text = normalizedText(element);
      const isNewProject =
        text === "NEW PROJECT" ||
        text === "+ NEW PROJECT" ||
        text.endsWith(" NEW PROJECT");
      const isOpenWorkspace =
        text === "CREATE WITH GOOGLE FLOW" ||
        text === "OPEN FLOW WORKSPACE" ||
        text === "OPEN WORKSPACE";

      if (!isNewProject && !isOpenWorkspace) {
        continue;
      }

      const clickable = element.closest("button, a, [role='button'], [tabindex]") || element;
      const rectangle = clickable.getBoundingClientRect();
      candidates.push({
        element: clickable,
        score: rectangle.width * rectangle.height + text.length * 100
      });
    }

    candidates.sort((left, right) => left.score - right.score);
    return candidates.length ? candidates[0].element : null;
  }

  function positionNewProjectButton(screen) {
    if (!screen) return;
    const replacementButton = screen.querySelector("button");
    if (!replacementButton) return;

    Object.assign(replacementButton.style, {
      position: "absolute",
      left: "50%",
      right: "auto",
      top: "auto",
      bottom: "clamp(28px, 7vh, 72px)",
      width: "192px",
      height: "128px",
      minWidth: "192px",
      minHeight: "128px",
      transform: "translateX(-50%)"
    });
  }

  function createPrivacyScreen() {
    const screen = document.createElement("section");
    screen.id = PRIVACY_SCREEN_ID;
    screen.setAttribute("aria-label", "Start a new Flow project");
    Object.assign(screen.style, {
      position: "fixed",
      left: "0",
      right: "0",
      top: "58px",
      bottom: "0",
      zIndex: "2147483000",
      background: "#000000",
      fontFamily: "Google Sans, Roboto, system-ui, -apple-system, sans-serif"
    });

    const button = document.createElement("button");
    button.type = "button";
    button.textContent = "+  New project";
    button.setAttribute("aria-label", "Create a new project");
    Object.assign(button.style, {
      width: "192px",
      height: "128px",
      minWidth: "192px",
      minHeight: "128px",
      padding: "0",
      border: "1px solid rgba(255, 255, 255, 0.16)",
      borderRadius: "32px",
      background: "#474747",
      boxShadow: "none",
      color: "#e0e0e0",
      fontSize: "16px",
      fontWeight: "500",
      lineHeight: "1",
      letterSpacing: "-0.2px",
      cursor: "pointer",
      transition: "background 160ms ease, border-color 160ms ease"
    });

    button.addEventListener("mouseenter", () => {
      button.style.background = "#525252";
      button.style.borderColor = "rgba(255, 255, 255, 0.24)";
    });
    button.addEventListener("mouseleave", () => {
      button.style.background = "#474747";
      button.style.borderColor = "rgba(255, 255, 255, 0.16)";
    });
    button.addEventListener("click", () => {
      const nativeButton = findNativeNewProjectButton();
      if (nativeButton) {
        nativeButton.click();
        return;
      }

      button.textContent = "Loading…";
      window.setTimeout(() => {
        const retryButton = findNativeNewProjectButton();
        button.textContent = "+  New project";
        if (retryButton) {
          retryButton.click();
          return;
        }

        // Do not trap the user behind the privacy layer if Google changes the
        // landing-page CTA again.
        const screen = document.getElementById(PRIVACY_SCREEN_ID);
        if (screen) screen.remove();
      }, 700);
    });

    screen.appendChild(button);
    window.requestAnimationFrame(() => positionNewProjectButton(screen));
    return screen;
  }

  function syncPrivacyScreen() {
    const existing = document.getElementById(PRIVACY_SCREEN_ID);

    if (!isFlowHomePage()) {
      if (existing) existing.remove();
      return;
    }

    if (!document.body) return;
    if (existing) {
      positionNewProjectButton(existing);
      return;
    }
    document.body.appendChild(createPrivacyScreen());
  }

  function watchLocation() {
    if (lastKnownUrl !== location.href) {
      lastKnownUrl = location.href;
      syncPrivacyScreen();
    } else if (isFlowHomePage()) {
      syncPrivacyScreen();
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", syncPrivacyScreen, { once: true });
  } else {
    syncPrivacyScreen();
  }

  window.setInterval(watchLocation, 400);
})();

// Keep the Flow video model restricted to the plan's enabled model.
(function () {
  "use strict";

  const ENABLED_VIDEO_MODEL = "VEO 3.1 - LITE [LOWER PRIORITY]";
  const LOCKED_VIDEO_MODELS = new Set([
    "OMNI FLASH",
    "VEO 3.1 - LITE",
    "VEO 3.1 - FAST",
    "VEO 3.1 - QUALITY"
  ]);
  const MODEL_ITEM_SELECTOR = [
    "button",
    "[role='option']",
    "[role='menuitem']",
    "[role='menuitemradio']",
    "[role='radio']",
    "li"
  ].join(",");
  const blockedModelEvents = [
    "pointerdown",
    "pointerup",
    "mousedown",
    "mouseup",
    "click",
    "touchstart",
    "touchend",
    "keydown"
  ];

  let modelScanScheduled = false;
  let selectingEnabledModel = false;

  function normalizedModelText(element) {
    return String(element && (element.innerText || element.textContent) || "")
      .replace(/[\u2010-\u2015\u2212]/g, "-")
      .replace(/\s+/g, " ")
      .trim()
      .toUpperCase();
  }

  function exactModelName(element) {
    const text = normalizedModelText(element);
    if (text === ENABLED_VIDEO_MODEL || LOCKED_VIDEO_MODELS.has(text)) return text;
    return "";
  }

  function closestModelItem(target) {
    if (!(target instanceof Element)) return null;

    const locked = target.closest("[data-flowbypak-model-locked='true']");
    if (locked) return locked;

    const item = target.closest(MODEL_ITEM_SELECTOR);
    if (item && exactModelName(item)) return item;
    return null;
  }

  function findMenuItem(label) {
    let current = label;

    for (let depth = 0; current && depth < 6; depth += 1) {
      const rectangle = current.getBoundingClientRect();
      const style = getComputedStyle(current);
      const isClickable = current.matches(MODEL_ITEM_SELECTOR) ||
        style.cursor === "pointer" ||
        current.hasAttribute("tabindex") ||
        current.hasAttribute("data-value") ||
        current.hasAttribute("data-radix-collection-item");

      if (
        isClickable &&
        rectangle.width >= 100 &&
        rectangle.height >= 24 &&
        rectangle.height <= 80
      ) {
        return current;
      }
      current = current.parentElement;
    }

    // Flow sometimes uses plain nested divs without ARIA roles. In that case,
    // the first compact row containing only the model label is the menu item.
    current = label;
    for (let depth = 0; current && depth < 5; depth += 1) {
      const rectangle = current.getBoundingClientRect();
      if (
        normalizedModelText(current) === normalizedModelText(label) &&
        rectangle.width >= 140 &&
        rectangle.height >= 28 &&
        rectangle.height <= 72
      ) {
        return current;
      }
      current = current.parentElement;
    }

    return label.parentElement || label;
  }

  function lockModelItem(item) {
    if (!(item instanceof HTMLElement) || item.dataset.flowbypakModelLocked === "true") {
      return;
    }

    item.dataset.flowbypakModelLocked = "true";
    item.setAttribute("aria-disabled", "true");
    item.title = "Locked — this model is not included in your plan";
    item.style.opacity = "0.42";
    item.style.cursor = "not-allowed";
    item.style.filter = "grayscale(0.8)";
    item.style.position = item.style.position || "relative";
    item.style.paddingRight = "42px";

    const badge = document.createElement("span");
    badge.dataset.flowbypakLockIcon = "true";
    badge.textContent = "🔒";
    badge.title = "Model locked";
    badge.setAttribute("aria-hidden", "true");
    Object.assign(badge.style, {
      position: "absolute",
      right: "14px",
      top: "50%",
      transform: "translateY(-50%)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: "24px",
      height: "24px",
      borderRadius: "7px",
      background: "rgba(15, 15, 18, 0.82)",
      border: "1px solid rgba(255, 255, 255, 0.16)",
      boxShadow: "0 2px 8px rgba(0, 0, 0, 0.35)",
      fontSize: "13px",
      pointerEvents: "none",
      zIndex: "2"
    });
    item.appendChild(badge);
  }

  function scanModelMenu() {
    modelScanScheduled = false;

    const elements = document.querySelectorAll(
      "button, [role='button'], [role='option'], [role='menuitem'], " +
      "[role='menuitemradio'], [role='radio'], li, div, span"
    );
    const labels = [];
    const visibleModelNames = new Set();

    for (const element of elements) {
      const modelName = exactModelName(element);
      if (!modelName) continue;
      const rectangle = element.getBoundingClientRect();
      if (rectangle.width <= 0 || rectangle.height <= 0) continue;
      labels.push({ element, modelName });
      visibleModelNames.add(modelName);
    }

    // A collapsed selector contains one model name. Two or more distinct names
    // means the video-model menu is open.
    if (visibleModelNames.size < 2) return;

    let enabledItem = null;
    let hasLockedMenuItem = false;
    const processedItems = new Set();

    for (const { element, modelName } of labels) {
      const item = findMenuItem(element);
      if (!item || processedItems.has(item)) continue;
      processedItems.add(item);

      if (LOCKED_VIDEO_MODELS.has(modelName)) {
        lockModelItem(item);
        hasLockedMenuItem = true;
      } else if (modelName === ENABLED_VIDEO_MODEL) {
        enabledItem = item;
        item.dataset.flowbypakModelEnabled = "true";
      }
    }

    // When the video-model menu is open and still shows another selection,
    // switch it to the only model enabled for this plan.
    if (hasLockedMenuItem && enabledItem && !selectingEnabledModel) {
      const selected = document.querySelector(
        "[role='option'][aria-selected='true'], " +
        "[role='menuitemradio'][aria-checked='true'], [role='radio'][aria-checked='true']"
      );
      if (!selected || normalizedModelText(selected) !== ENABLED_VIDEO_MODEL) {
        selectingEnabledModel = true;
        enabledItem.click();
        window.setTimeout(() => {
          selectingEnabledModel = false;
        }, 250);
      }
    }
  }

  function scheduleModelScan() {
    if (modelScanScheduled) return;
    modelScanScheduled = true;
    window.requestAnimationFrame(scanModelMenu);
  }

  for (const eventName of blockedModelEvents) {
    document.addEventListener(eventName, (event) => {
      const item = closestModelItem(event.target);
      if (!item || item.dataset.flowbypakModelLocked !== "true") return;
      event.preventDefault();
      event.stopImmediatePropagation();
    }, true);
  }

  new MutationObserver(scheduleModelScan).observe(document.documentElement, {
    childList: true,
    subtree: true,
    characterData: true
  });

  scheduleModelScan();
})();

// Portal Auth Bridge Listener for Web Portal
(function () {
  "use strict";
  function detectPortalAuth() {
    const bridge = document.getElementById("flowbypak-auth-bridge");
    if (bridge) {
      const isLoggedIn = bridge.getAttribute("data-logged-in") === "1";
      const email = bridge.getAttribute("data-email") || "";
      const days = bridge.getAttribute("data-days") || 0;
      const sid = bridge.getAttribute("data-sid") || "";
      const baseUrl = bridge.getAttribute("data-base-url") || location.origin;

      try {
        chrome.runtime.sendMessage({
          action: "PORTAL_AUTH_DETECTED",
          isLoggedIn,
          email,
          days,
          sid,
          origin: baseUrl
        });
      } catch(e) {}
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", detectPortalAuth);
  } else {
    detectPortalAuth();
  }
  setInterval(detectPortalAuth, 2000);
})();

// Google Flow In-Page Cookie Switcher Widget (C1..C5)
(function () {
  "use strict";
  const hostname = location.hostname.toLowerCase();
  if (!hostname.includes("labs.google")) return;

  const WIDGET_ID = "flowbypak-cookie-switcher-widget";

  async function renderSwitcherWidget() {
    if (document.getElementById(WIDGET_ID)) return;

    let storage;
    try {
      storage = await chrome.storage.local.get(["activeSlot", "availableSlots", "status"]);
    } catch (e) {
      return;
    }

    if (storage.status !== "connected") return;

    const activeSlot = storage.activeSlot || "C1";
    const availableSlots = storage.availableSlots || [{ key: "C1", name: "Cookie 1" }];

    const widget = document.createElement("div");
    widget.id = WIDGET_ID;
    Object.assign(widget.style, {
      position: "fixed",
      bottom: "20px",
      right: "20px",
      zIndex: "2147483646",
      fontFamily: "system-ui, -apple-system, sans-serif",
      fontSize: "12px",
      fontWeight: "700",
      userSelect: "none"
    });

    const badge = document.createElement("div");
    badge.innerText = `⚡ ${activeSlot}`;
    badge.title = "Click to switch cookie profile (C1-C5)";
    Object.assign(badge.style, {
      background: "linear-gradient(135deg, #8b5cf6, #6366f1)",
      color: "#ffffff",
      padding: "8px 14px",
      borderRadius: "20px",
      boxShadow: "0 4px 16px rgba(139, 92, 246, 0.4)",
      cursor: "pointer",
      display: "flex",
      alignItems: "center",
      gap: "6px",
      border: "1px solid rgba(255, 255, 255, 0.2)",
      transition: "all 0.2s ease"
    });

    const menu = document.createElement("div");
    menu.id = "flowbypak-cookie-menu";
    Object.assign(menu.style, {
      display: "none",
      position: "absolute",
      bottom: "42px",
      right: "0",
      background: "rgba(15, 23, 42, 0.95)",
      backdropFilter: "blur(12px)",
      border: "1px solid rgba(139, 92, 246, 0.3)",
      borderRadius: "14px",
      padding: "8px",
      boxShadow: "0 10px 25px rgba(0,0,0,0.5)",
      width: "160px",
      flexDirection: "column",
      gap: "4px"
    });

    const menuHeader = document.createElement("div");
    menuHeader.innerText = "Switch Cookie Profile";
    Object.assign(menuHeader.style, {
      padding: "4px 8px 8px",
      fontSize: "10px",
      color: "#94a3b8",
      textTransform: "uppercase",
      letterSpacing: "0.05em",
      borderBottom: "1px solid rgba(255,255,255,0.08)",
      marginBottom: "4px"
    });
    menu.appendChild(menuHeader);

    availableSlots.forEach((slot) => {
      const item = document.createElement("div");
      const isCurrent = slot.key === activeSlot;
      item.innerText = `${isCurrent ? "🟢 " : "⚪ "}${slot.key} (${slot.name || "Cookie"})`;
      Object.assign(item.style, {
        padding: "8px 10px",
        borderRadius: "8px",
        cursor: "pointer",
        color: isCurrent ? "#a7f3d0" : "#e2e8f0",
        background: isCurrent ? "rgba(16, 185, 129, 0.15)" : "transparent",
        fontWeight: isCurrent ? "700" : "500",
        transition: "background 0.2s ease"
      });

      item.addEventListener("mouseenter", () => {
        if (!isCurrent) item.style.background = "rgba(255, 255, 255, 0.08)";
      });
      item.addEventListener("mouseleave", () => {
        if (!isCurrent) item.style.background = "transparent";
      });

      item.addEventListener("click", (e) => {
        e.stopPropagation();
        badge.innerText = `⏳ ${slot.key}...`;
        menu.style.display = "none";
        chrome.runtime.sendMessage({ action: "SWITCH_COOKIE_SLOT", slot: slot.key }, () => {
          setTimeout(() => location.reload(), 500);
        });
      });

      menu.appendChild(item);
    });

    badge.addEventListener("click", (e) => {
      e.stopPropagation();
      menu.style.display = menu.style.display === "none" ? "flex" : "none";
    });

    document.addEventListener("click", () => {
      menu.style.display = "none";
    });

    widget.appendChild(menu);
    widget.appendChild(badge);
    document.body.appendChild(widget);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", renderSwitcherWidget);
  } else {
    renderSwitcherWidget();
  }
  setInterval(renderSwitcherWidget, 3000);
})();
