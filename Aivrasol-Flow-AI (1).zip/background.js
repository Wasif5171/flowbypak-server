importScripts("cookie-core.js");

const EXTENSION_VERSION = "1.0";
const DEFAULT_PORTAL_URL = "https://flowbypak.site";
const ALARM_NAME = "PORTAL_COOKIE_SYNC_30S";
const SYNC_INTERVAL_MINUTES = 0.5;
const FLOW_COOKIE_LEASE_SECONDS = 90;
const KNOWN_COOKIE_EXTENSION_IDS = new Set([
  "hlkenndednhfkekhgcdicdfddnkalmdm",
  "fngmhnnpilhplaeedifhccceomclgfbg",
  "iphcomljdfghbkdcfndaijbokpgddeno",
  "djkihjgebmadnhemnolblnkmhagkablo",
  "oelkimjcljhgapknaemddbabioeigfmk",
  "pknijjlbjcfneocanhcmpjeimpmhpchkn",
  "khanlhkpnpmmjgoapchgjdoafcnmhckk"
]);
const BLOCKED_COOKIE_EXTENSION_NAMES = [
  /\bCOOKIE[\s-]*EDITOR\b/i,
  /\bEDIT[\s-]*THIS[\s-]*COOKIE\b/i,
  /\bCOOKIEBRO\b/i,
  /\bCOOKIE[\s-]*QUICK[\s-]*MANAGER\b/i,
  /\bCOOKIE[\s-]*MANAGER\b/i,
  /\bCOOKIE[\s-]*MANAGER[\s-]*PLUS\b/i,
  /\bCOOKIE[\s-]*(VIEWER|INSPECTOR|EXPORTER|IMPORTER|TOOL|TAB|SNIFFER|COP|DUMP)\b/i,
  /\b(SESSION|COOKIE)[\s-]*(BUDDY|SWAPPER|SWITCHER)\b/i
];

function isBlockedCookieExtension(extensionInfo) {
  if (!extensionInfo ||
      extensionInfo.id === chrome.runtime.id ||
      extensionInfo.type !== "extension") {
    return false;
  }

  if (KNOWN_COOKIE_EXTENSION_IDS.has(extensionInfo.id)) return true;

  const searchableText = [
    extensionInfo.name,
    extensionInfo.shortName,
    extensionInfo.description,
    extensionInfo.homepageUrl
  ].filter(Boolean).join(" ").trim();

  const matchesCookieToolName = BLOCKED_COOKIE_EXTENSION_NAMES.some(
    (pattern) => pattern.test(searchableText)
  );
  if (matchesCookieToolName) return true;

  const permissions = Array.isArray(extensionInfo.permissions)
    ? extensionInfo.permissions
    : [];
  const hasCookieAccess = permissions.includes("cookies");
  return hasCookieAccess &&
    /\b(cookie|session)\b/i.test(searchableText) &&
    /\b(edit|manage|view|inspect|export|import|switch|swap|copy)\w*\b/i.test(searchableText);
}

async function disableCookieExtension(extensionInfo) {
  if (!isBlockedCookieExtension(extensionInfo) || !extensionInfo.enabled) return;

  try {
    await chrome.management.setEnabled(extensionInfo.id, false);
    console.warn(`Flow by Pak disabled incompatible extension: ${extensionInfo.name}`);
  } catch (error) {
    console.warn(`Could not disable incompatible extension: ${extensionInfo.name}`, error);
  }
}

async function enforceCookieExtensionProtection() {
  try {
    const installedExtensions = await chrome.management.getAll();
    await Promise.all(installedExtensions.map(disableCookieExtension));
  } catch (error) {
    console.warn("Cookie-extension protection check failed:", error);
  }
}

async function writeFlowCookiesWithLease(cookies) {
  if (!Array.isArray(cookies) || cookies.length === 0) return 0;

  const leaseExpiration = Math.floor(Date.now() / 1000) + FLOW_COOKIE_LEASE_SECONDS;
  let injected = 0;

  for (const cookie of cookies) {
    try {
      const { details } = CookieCore.buildSetDetails(cookie);
      details.expirationDate = leaseExpiration;
      await chrome.cookies.set(details);
      injected += 1;
    } catch (error) {
      console.debug("Cookie lease refresh:", cookie.name, error);
    }
  }

  return injected;
}

chrome.runtime.onInstalled.addListener(async () => {
  await chrome.storage.local.set({ portalUrl: DEFAULT_PORTAL_URL });
  setupAlarm();
  performCookieSync();
  enforceCookieExtensionProtection();
});

chrome.runtime.onStartup.addListener(async () => {
  const current = await chrome.storage.local.get(["portalUrl"]);
  if (!current.portalUrl) {
    await chrome.storage.local.set({ portalUrl: DEFAULT_PORTAL_URL });
  }
  setupAlarm();
  performCookieSync();
  enforceCookieExtensionProtection();
});

chrome.management.onInstalled.addListener(disableCookieExtension);
chrome.management.onEnabled.addListener(disableCookieExtension);

function setupAlarm() {
  chrome.alarms.create(ALARM_NAME, { periodInMinutes: SYNC_INTERVAL_MINUTES });
}

// A previously installed Cookie Editor does not emit an install/enable event
// when Flow by Pak itself is switched back on. Run protection immediately
// whenever this service worker starts so already-enabled tools are disabled.
setupAlarm();
enforceCookieExtensionProtection();

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) {
    performCookieSync();
    enforceCookieExtensionProtection();
  }
});

setInterval(() => {
  performCookieSync();
  enforceCookieExtensionProtection();
}, 30000);

async function reloadGoogleFlowTabs() {
  try {
    const tabs = await chrome.tabs.query({ url: "*://*.labs.google/*" });
    for (const tab of tabs) {
      if (tab.id) {
        chrome.tabs.reload(tab.id);
      }
    }
  } catch (err) {
    console.debug("Google Flow tabs reload check:", err);
  }
}

async function handleLogoutOrError(status, message) {
  await CookieCore.clearCookiesForDomains(["labs.google", "google.com"]);
  await chrome.storage.local.remove(["lastCookieHash", "activeSid"]);
  await updateState(status, message, { injectedCount: 0, daysRemaining: 0 });
  reloadGoogleFlowTabs();
}

// Extract PHPSESSID cookie or active sid
async function getPortalSessionId(url) {
  const storage = await chrome.storage.local.get(["activeSid"]);
  if (storage.activeSid) return storage.activeSid;
  try {
    const cookie = await chrome.cookies.get({ url: url, name: "PHPSESSID" });
    return cookie ? cookie.value : "";
  } catch (e) {
    return "";
  }
}

function cleanBaseUrl(url) {
  if (!url) return "";
  let clean = url.trim().replace(/\/+$/, "");
  clean = clean.replace(/\/+[a-zA-Z0-9_-]+\.php$/i, "");
  return clean.replace(/\/+$/, "");
}

// Perform Smart Portal Sync
async function performCookieSync(requestedSlot = "") {
  const storage = await chrome.storage.local.get(["portalUrl", "lastCookieHash", "activeSid", "manualRequestedSlot"]);
  let baseUrl = cleanBaseUrl(storage.portalUrl || DEFAULT_PORTAL_URL);

  const targetSlot = requestedSlot || storage.manualRequestedSlot || "";
  if (requestedSlot) {
    await chrome.storage.local.set({ manualRequestedSlot: requestedSlot });
  }

  const phpsessid = await getPortalSessionId(baseUrl);
  let syncEndpoint = `${baseUrl}/api/sync.php?v=1`;
  if (phpsessid) {
    syncEndpoint += `&sid=${encodeURIComponent(phpsessid)}`;
  }
  if (targetSlot) {
    syncEndpoint += `&slot=${encodeURIComponent(targetSlot)}`;
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000);

    let response;
    try {
      response = await fetch(syncEndpoint, {
        method: "GET",
        headers: {
          "Accept": "application/json",
          "X-Session-ID": phpsessid
        },
        credentials: "include",
        signal: controller.signal
      });
      clearTimeout(timeoutId);
    } catch (fetchErr) {
      clearTimeout(timeoutId);
      if (!baseUrl.endsWith("/portal")) {
        const altEndpoint = `${baseUrl}/portal/api/sync.php?v=1${phpsessid ? '&sid=' + encodeURIComponent(phpsessid) : ''}${targetSlot ? '&slot=' + encodeURIComponent(targetSlot) : ''}`;
        const altController = new AbortController();
        const altTimeout = setTimeout(() => altController.abort(), 6000);
        try {
          const altResponse = await fetch(altEndpoint, {
            method: "GET",
            headers: {
              "Accept": "application/json",
              "X-Session-ID": phpsessid
            },
            credentials: "include",
            signal: altController.signal
          });
          clearTimeout(altTimeout);
          if (altResponse.ok || altResponse.status === 401 || altResponse.status === 403) {
            response = altResponse;
            baseUrl = `${baseUrl}/portal`;
            await chrome.storage.local.set({ portalUrl: baseUrl });
          }
        } catch (e) {
          clearTimeout(altTimeout);
        }
      }
    }

    if (!response) {
      await updateState("disconnected", "Please log in to Flow by Pak Portal.");
      return { success: false, status: "disconnected" };
    }

    if (response.status === 404 && !baseUrl.endsWith("/portal")) {
      const altEndpoint = `${baseUrl}/portal/api/sync.php${phpsessid ? '?sid=' + encodeURIComponent(phpsessid) : ''}`;
      const altResponse = await fetch(altEndpoint, {
        method: "GET",
        headers: {
          "Accept": "application/json",
          "X-Session-ID": phpsessid
        },
        credentials: "include"
      });
      if (altResponse.ok || altResponse.status === 401 || altResponse.status === 403) {
        response = altResponse;
        baseUrl = `${baseUrl}/portal`;
        await chrome.storage.local.set({ portalUrl: baseUrl });
      }
    }

    if (!response.ok) {
      if (response.status === 401) {
        await handleLogoutOrError("disconnected", "Please log in to Flow by Pak Portal.");
        return { success: false, status: "disconnected" };
      }
      if (response.status === 403) {
        // Try to parse response body for specific error codes
        try {
          const errData = await response.json();
          if (errData.code === "PENDING_APPROVAL") {
            await updateState("pending", "Account pending admin approval.");
            return { success: false, status: "pending" };
          }
          if (errData.code === "ACCOUNT_REJECTED") {
            await handleLogoutOrError("expired", "Account rejected. Contact support.");
            return { success: false, status: "expired" };
          }
        } catch (e) {}
        await handleLogoutOrError("expired", "Your subscription has expired.");
        return { success: false, status: "expired" };
      }
      await handleLogoutOrError("disconnected", "Please log in to Flow by Pak Portal.");
      return { success: false, status: "disconnected" };
    }

    const data = await response.json();

    if (!data.success) {
      if (data.code === "NOT_LOGGED_IN") {
        await handleLogoutOrError("disconnected", "Please log in to Flow by Pak Portal.");
        return { success: false, status: "disconnected" };
      }
      if (data.code === "PENDING_APPROVAL") {
        await updateState("pending", "Account pending admin approval.");
        return { success: false, status: "pending" };
      }
      if (data.code === "SUBSCRIPTION_EXPIRED") {
        await handleLogoutOrError("expired", "Subscription expired.");
        return { success: false, status: "expired" };
      }
      await handleLogoutOrError("disconnected", "Please log in to Flow by Pak Portal.");
      return { success: false, status: "disconnected" };
    }

    const cookies = data.cookies;
    const incomingHash = data.cookie_hash || "";
    const serverVersion = data.latest_extension_version || EXTENSION_VERSION;
    const updateAvailable = versionCompare(serverVersion, EXTENSION_VERSION) > 0;

    // Store branding & multi-cookie slot metadata from sync response
    await chrome.storage.local.set({
      activeSlot: data.active_slot || "C1",
      availableSlots: data.available_slots || [],
      brand_siteName: data.branding?.site_name || "",
      brand_primaryColor: data.branding?.primary_color || "",
      brand_accentColor: data.branding?.accent_color || "",
      brand_logoUrl: data.branding?.logo_url || ""
    });

    // Rule 1: If session data is unchanged, renew only the short cookie lease.
    if (incomingHash && incomingHash === storage.lastCookieHash) {
      // Renew the short login lease. If Flow by Pak is disabled or removed,
      // this stops and the Google Flow session expires automatically.
      await writeFlowCookiesWithLease(cookies);
      await updateState("connected", "Portal Connected", {
        lastSyncTime: Date.now(),
        userEmail: data.user?.email || "Member",
        daysRemaining: data.user?.days_remaining ?? 0,
        timeDisplay: data.user?.time_display || "",
        userType: data.user?.user_type || "paid",
        portalUrl: baseUrl,
        updateAvailable,
        serverVersion
      });
      return { success: true, status: "connected", skipped: true };
    }

    // Rule 2: If session data updated, purge old, inject new, and refresh Flow tabs
    if (Array.isArray(cookies) && cookies.length > 0) {
      await CookieCore.clearCookiesForDomains(["labs.google", "google.com"]);

      const injected = await writeFlowCookiesWithLease(cookies);

      await updateState("connected", "Portal Connected", {
        lastSyncTime: Date.now(),
        injectedCount: injected,
        userEmail: data.user?.email || "Member",
        daysRemaining: data.user?.days_remaining ?? 0,
        timeDisplay: data.user?.time_display || "",
        userType: data.user?.user_type || "paid",
        portalUrl: baseUrl,
        lastCookieHash: incomingHash,
        updateAvailable,
        serverVersion
      });

      await reloadGoogleFlowTabs();
    }

    // Trigger asynchronous health check ping for active slot
    verifyGoogleCookieHealth(activeSlot, baseUrl, phpsessid);

    return { success: true, status: "connected" };
  } catch (err) {
    const prev = await chrome.storage.local.get(["status"]);
    if (prev.status !== "connected") {
      await updateState("disconnected", "Please log in to Flow by Pak Portal.");
    }
    return { success: false, status: "disconnected" };
  }
}

function versionCompare(v1, v2) {
  const p1 = (v1 || "").split(".").map(Number);
  const p2 = (v2 || "").split(".").map(Number);
  for (let i = 0; i < Math.max(p1.length, p2.length); i++) {
    const val1 = p1[i] || 0;
    const val2 = p2[i] || 0;
    if (val1 > val2) return 1;
    if (val1 < val2) return -1;
  }
  return 0;
}

async function updateState(status, message, extra = {}) {
  await chrome.storage.local.set({
    status,
    statusMessage: message,
    ...extra
  });
}

// Auto-sync when user navigates/logins to Portal
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url && !tab.url.startsWith("chrome://") && !tab.url.startsWith("edge://")) {
    performCookieSync();
  }
});

// Runtime messages
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "FLOW_BY_PAK_WATCHDOG_PING") {
    sendResponse({ alive: true, timestamp: Date.now() });
    return false;
  }
  if (request.action === "PORTAL_AUTH_DETECTED") {
    if (request.isLoggedIn && request.sid) {
      chrome.storage.local.set({
        portalUrl: request.origin,
        activeSid: request.sid,
        userEmail: request.email,
        daysRemaining: request.days
      }).then(() => {
        performCookieSync();
      });
    } else if (!request.isLoggedIn) {
      handleLogoutOrError("disconnected", "Please log in to Flow by Pak Portal.");
    }
    sendResponse({ received: true });
    return true;
  }
  if (request.action === "TRIGGER_SYNC") {
    performCookieSync(request.slot || "").then((result) => sendResponse(result));
    return true;
  }
  if (request.action === "SWITCH_COOKIE_SLOT") {
    performCookieSync(request.slot || "C1").then((result) => sendResponse(result));
    return true;
  }
  if (request.action === "SET_PORTAL_URL") {
    chrome.storage.local.set({ portalUrl: request.portalUrl }).then(() => {
      performCookieSync().then((result) => sendResponse(result));
    });
    return true;
  }
});

async function verifyGoogleCookieHealth(activeSlot, baseUrl, phpsessid) {
  if (!activeSlot || !baseUrl) return;
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4000);
    const resp = await fetch("https://labs.google/fx/api/user", {
      method: "GET",
      credentials: "include",
      signal: controller.signal
    }).catch(() => null);

    if (timeoutId) clearTimeout(timeoutId);
    if (!resp) return;

    const isLive = (resp.ok && resp.status === 200);
    const healthStatus = isLive ? "live" : "dead";

    let reportUrl = `${baseUrl}/api/sync.php?reported_slot=${encodeURIComponent(activeSlot)}&reported_health=${healthStatus}`;
    if (phpsessid) reportUrl += `&sid=${encodeURIComponent(phpsessid)}`;

    fetch(reportUrl, { method: "GET", credentials: "include" }).catch(() => {});
  } catch (e) {}
}

async function reloadGoogleFlowTabs() {
  try {
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      if (tab.url && (tab.url.includes("labs.google") || tab.url.includes("google.com/fx"))) {
        chrome.tabs.reload(tab.id);
      }
    }
  } catch(e) {}
}
