# 🚀 Chrome Extension Setup & Customization Guide

This Chrome Extension connects Google Flow AI directly to your Web Portal access system.

---

## 🌐 1. Universal & Global Out-of-the-Box Connection
This extension is **100% Global & Universal**. You do **NOT** need to edit code when hosting your portal on a new domain!

* **How it connects:**
  1. Open your web portal (e.g. `https://paktools.store`, `http://localhost/flowbypak/portal`, or any domain).
  2. Log into your account on the web portal.
  3. The extension automatically detects your login session, links to your portal, syncs Google Flow cookies, and turns **🟢 Connected**.

---

## 🎨 2. How to Customize Branding Manually (Optional)

If you want to edit the Extension's name, logo, or default links manually:

### A. Extension Name & Description
Open `manifest.json` and edit:
```json
"name": "Your Brand Name — Flow AI",
"short_name": "Your Brand",
"description": "Your Custom Subtitle"
```

### B. Default Portal Login Link
Open `popup.js` and `background.js` and edit the default URL fallback:
```javascript
const DEFAULT_PORTAL_URL = "https://yourdomain.com/portal/login.php";
```

### C. Extension Logos & Icons
Replace the following image files in the extension folder with your brand's square logo:
* `logo.png` (Popup Header Logo)
* `icon16.png` (Toolbar Icon 16x16)
* `icon32.png` (Toolbar Icon 32x32)
* `icon48.png` (Chrome Extensions Manager 48x48)
* `icon128.png` (Chrome Webstore Icon 128x128)

> 💡 **Tip:** If you use the Admin Panel on your portal, clicking **⚡ Build & Re-Brand Extension ZIP Now** will automatically customize all of the above files for you in 1 click!

---

## 🛠️ 3. How to Install Extension in Browser

1. Download or extract the extension folder (`Flow-by-Pak`).
2. Open Chrome and navigate to `chrome://extensions`.
3. Enable **Developer Mode** (toggle at top-right).
4. Click **Load Unpacked** and select the `Flow-by-Pak` folder.
5. Log into your web portal and click **🚀 Launch Flow AI**!
