(function () {
  "use strict";

  const HEARTBEAT_TYPE = "FLOW_BY_PAK_EXTENSION_HEARTBEAT";
  const DISCONNECTED_TYPE = "FLOW_BY_PAK_EXTENSION_DISCONNECTED";
  const HEARTBEAT_ACTION = "FLOW_BY_PAK_WATCHDOG_PING";
  let pingInFlight = false;
  let consecutiveFailures = 0;

  function reportFailure() {
    consecutiveFailures += 1;
    if (consecutiveFailures < 2) return;
    window.postMessage({
      type: DISCONNECTED_TYPE,
      timestamp: Date.now()
    }, "*");
  }

  function sendHeartbeat() {
    if (pingInFlight) return;
    pingInFlight = true;

    try {
      chrome.runtime.sendMessage({ action: HEARTBEAT_ACTION }, (response) => {
        pingInFlight = false;

        // Reading lastError prevents an unchecked-runtime-error warning. More
        // importantly, no page heartbeat is emitted unless the live extension
        // service worker explicitly acknowledges this ping.
        if (chrome.runtime.lastError || !response || response.alive !== true) {
          reportFailure();
          return;
        }

        consecutiveFailures = 0;
        window.postMessage({
          type: HEARTBEAT_TYPE,
          timestamp: Date.now()
        }, "*");
      });
    } catch (_error) {
      pingInFlight = false;
      reportFailure();
      // When the extension is disabled or removed, heartbeats stop. The
      // page-world watchdog then signs the Flow session out immediately.
    }
  }

  sendHeartbeat();
  window.setInterval(sendHeartbeat, 250);
})();
